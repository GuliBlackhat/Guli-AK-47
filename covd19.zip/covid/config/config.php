<?php 

define('BASE_PATH', dirname(dirname(__FILE__)));
define('APP_FOLDER','simpleadmin');


require_once BASE_PATH.'/lib/MysqliDb.php';
$servername = "localhost";
$username = "superbot";
$password = "Eugene02091993";
$dbname = "superbot";

$transport_key = "26kozQaKwRuNJ24t";

$db =new MysqliDb($servername,$username,$password,$dbname);
